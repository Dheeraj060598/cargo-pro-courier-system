<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AddressClient extends Model
{
    protected $guarded = [];
    protected $table = 'address_client';
}
