<?php 
$addon = \App\Addon::where('unique_identifier', 'spot-cargo-shipment-addon')->first();
?>
<?php if($addon != null): ?>
    <?php if($addon->activated): ?>
        <?php if(in_array(Auth::user()->user_type , ['admin','customer','branch']) || in_array('1001', json_decode(Auth::user()->staff->role->permissions ?? "[]")) || Auth::user()->user_type == 'branch' || Auth::user()->user_type == 'client'): ?>
            <li class="menu-item menu-item-rel ">
                <a href="<?php echo e(route('admin.shipments.create')); ?>" class="btn btn-success btn-sm mr-3">
                    + <?php echo e(translate('Add Shipment')); ?><i class="ml-2 flaticon2-box-1"></i>
                </a>
            </li>
        <?php endif; ?>
        <li class="menu-item menu-item-rel ">
            <a href="<?php echo e(route('admin.shipments.track')); ?>" class="btn btn-primary btn-sm mr-3">
                <?php echo e(translate('Track Shipment')); ?><i class="ml-2 flaticon2-search"></i>
            </a>
        </li>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH /Volumes/Collection/Algoriza/Bdaia/Codecanyon/framework/resources/views/backend/inc/addons/topbar/shipment_sidenav.blade.php ENDPATH**/ ?>