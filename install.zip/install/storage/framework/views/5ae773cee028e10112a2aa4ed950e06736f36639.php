<?php
$addon = \App\Addon::where('unique_identifier', 'spot-cargo-shipment-addon')->first();
$user_type = Auth::user()->user_type;
?>
<!--Shipments-->
<?php if($addon != null): ?>
    <?php if($addon->activated): ?>
        <?php if( in_array($user_type,['admin','customer','branch']) || in_array('1108', json_decode(Auth::user()->staff->role->permissions ?? "[]"))): ?>
            <li class="menu-item menu-item-submenu  <?php echo e(areActiveRoutes(['admin.shipments.index','admin.shipments.update','admin.shipments.import','admin.shipments.add.by.api','admin.shipments.create','admin.shipments.show'])); ?> <?php $__currentLoopData = \App\Shipment::status_info(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e(areActiveRoutes([$item['route_name']])); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> " aria-haspopup="true" data-menu-toggle="hover">
                <a href="javascript:;" class="menu-link menu-toggle">
                    <i class="menu-icon fas fa-box-open"></i>
                    <span class="menu-text"><?php echo e(translate('Shipments')); ?></span>
                    <i class="menu-arrow"></i>
                </a>
                <div class="menu-submenu">
                    <i class="menu-arrow"></i>
                    <ul class="menu-subnav">
                        <li class="menu-item menu-item-parent" aria-haspopup="true">
                            <span class="menu-link">
                                <span class="menu-text"><?php echo e(translate('Shipments')); ?></span>
                            </span>
                        </li>

                        <?php if( in_array($user_type,['admin','customer','captain','branch']) || in_array('1108', json_decode(Auth::user()->staff->role->permissions ?? "[]"))): ?>
                            <li class="menu-item <?php echo e(areActiveRoutes(['admin.shipments.create'])); ?>" aria-haspopup="true">
                                <a href="<?php echo e(route('admin.shipments.create')); ?>" class="menu-link">
                                        <i class="menu-bullet menu-icon flaticon2-plus" style="font-size: 10px;"></i>
                                    <span class="menu-text"><?php echo e(translate('Add Shipment')); ?></span>
                                </a>
                            </li>

                            <?php if(in_array($user_type,['customer'])): ?>
                                <li class="menu-item <?php echo e(areActiveRoutes(['admin.shipments.import'])); ?>" aria-haspopup="true">
                                    <a href="<?php echo e(route('admin.shipments.import')); ?>" class="menu-link">
                                        <i class="menu-bullet menu-icon flaticon2-plus" style="font-size: 10px;"></i>
                                        <span class="menu-text"><?php echo e(translate('Import Shipments')); ?></span>
                                    </a>
                                </li>
                            <?php endif; ?>
                            
                        <?php endif; ?>

                        <?php if( in_array($user_type,['admin','customer']) || in_array('1107', json_decode(Auth::user()->staff->role->permissions ?? "[]"))): ?>
                            <li class="menu-item <?php echo e(areActiveRoutes(['admin.shipments.add.by.api'])); ?>"  aria-haspopup="true">
                                <a href="<?php echo e(route('admin.shipments.add.by.api')); ?>" class="menu-link">
                                    <i class="menu-bullet menu-icon flaticon2-plus" style="font-size: 10px;"></i>
                                    <span class="menu-text"><?php echo e(translate('Shipments Api')); ?></span>

                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if( in_array($user_type,['admin','captain']) || in_array('1109', json_decode(Auth::user()->staff->role->permissions ?? "[]"))): ?>
                            <li class="menu-item <?php echo e(areActiveRoutes(['admin.shipments.barcode.scanner'])); ?>" aria-haspopup="true">
                                <a href="<?php echo e(route('admin.shipments.barcode.scanner')); ?>" class="menu-link">
                                    <i class="menu-bullet menu-bullet-dot">
                                        <span></span>
                                    </i>
                                    <span class="menu-text"><?php echo e(translate('Barcode Scanner')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(\App\ShipmentSetting::getVal('is_shipping_calc_required')=='1'): ?>
                            <li class="menu-item <?php echo e(areActiveRoutes(['shipment-calc'])); ?>" aria-haspopup="true">
                                <a href="<?php echo e(route('shipment-calc')); ?>" class="menu-link">
                                    <i class="menu-bullet menu-bullet-dot">
                                        <span></span>
                                    </i>
                                    <span class="menu-text"><?php echo e(translate('Shipping calculator')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>

                        
                        <?php if( in_array($user_type,['admin','customer','captain','branch']) || in_array('1108', json_decode(Auth::user()->staff->role->permissions ?? "[]"))): ?>

                            <li class="menu-item <?php echo e(areActiveRoutes(['admin.shipments.index','admin.shipments.show',])); ?>" aria-haspopup="true">
                                <a href="<?php echo e(route('admin.shipments.index')); ?>" class="menu-link">
                                    <i class="menu-bullet menu-bullet-dot">
                                        <span></span>
                                    </i>
                                    <span class="menu-text"><?php echo e(translate('All Shipments')); ?></span>

                                </a>
                            </li>
                        <?php endif; ?>
                        <?php $__currentLoopData = \App\Shipment::status_info(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(in_array($user_type,['admin','customer','captain','branch']) || in_array($item['permissions'], json_decode(Auth::user()->staff->role->permissions ?? "[]"))): ?>
                                <?php if($item['status'] == \App\Shipment::SAVED_STATUS): ?>
                                <li class="menu-item <?php if(isset($type) && $type==\App\Shipment::PICKUP && isset($status) && $status ==  $item['status']): ?> menu-item-active menu-item-open <?php endif; ?>" aria-haspopup="true">
                                    <a href="<?php echo e(route($item['route_name'],['status'=>$item['status'],'type'=>\App\Shipment::PICKUP])); ?>" class="menu-link">
                                        <i class="menu-bullet menu-bullet-dot">
                                            <span></span>
                                        </i>
                                        <span class="menu-text"><?php echo e(translate('Saved Pickup')); ?></span>

                                    </a>
                                </li>
                                <li class="menu-item <?php if(isset($type) && $type==\App\Shipment::DROPOFF && isset($status) && $status ==  $item['status']): ?> menu-item-active menu-item-open <?php endif; ?>" aria-haspopup="true">
                                    <a href="<?php echo e(route($item['route_name'],['status'=>$item['status'],'type'=>\App\Shipment::DROPOFF])); ?>" class="menu-link">
                                        <i class="menu-bullet menu-bullet-dot">
                                            <span></span>
                                        </i>
                                        <span class="menu-text"><?php echo e(translate('Saved Dropoff')); ?></span>

                                    </a>
                                </li>
                                <?php elseif($item['status'] == \App\Shipment::REQUESTED_STATUS): ?>
                                <li class="menu-item <?php if(isset($type) && $type==\App\Shipment::PICKUP && isset($status) && $status == $item['status']): ?> menu-item-active menu-item-open <?php endif; ?>" aria-haspopup="true">
                                    <a href="<?php echo e(route($item['route_name'],['status'=>$item['status'],'type'=>\App\Shipment::PICKUP])); ?>" class="menu-link">
                                        <i class="menu-bullet menu-bullet-dot">
                                            <span></span>
                                        </i>
                                        <span class="menu-text"><?php echo e(translate('Requested Pickup')); ?></span>

                                    </a>
                                </li>

                                <?php else: ?>
                                <li class="menu-item <?php echo e(areActiveRoutes([$item['route_name']])); ?>" aria-haspopup="true">
                                    <a href="<?php echo e(route($item['route_name'],['status'=>$item['status']])); ?>" class="menu-link">
                                        <i class="menu-bullet menu-bullet-dot">
                                            <span></span>
                                        </i>
                                        <span class="menu-text"><?php echo e($item['text']); ?></span>

                                    </a>
                                </li>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </li>
        <?php endif; ?>
    <?php endif; ?>
<?php endif; ?>

<!-- Missions-->
<?php
$addon = \App\Addon::where('unique_identifier', 'spot-cargo-shipment-addon')->first();
$user_type = Auth::user()->user_type;
?>
<?php if($addon != null): ?>
    <?php if($addon->activated): ?>
        <?php if(in_array($user_type, ['admin','captain','branch']) || in_array('1008', json_decode(Auth::user()->staff->role->permissions ?? "[]"))): ?>
            <li class="menu-item menu-item-submenu  <?php echo e(areActiveRoutes(['admin.missions.index','admin.missions.update','admin.missions.create','admin.missions.show','admin.missions.get.manifest'])); ?> <?php $__currentLoopData = \App\Mission::status_info(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e(areActiveRoutes([$item['route_name']])); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> " aria-haspopup="true" data-menu-toggle="hover">
                <a href="javascript:;" class="menu-link menu-toggle">
                    <i class="menu-icon fas fa-shipping-fast"></i>
                    <span class="menu-text"><?php echo e(translate('Missions')); ?></span>
                    <i class="menu-arrow"></i>
                </a>
                <div class="menu-submenu">
                    <i class="menu-arrow"></i>
                    <ul class="menu-subnav">
                        <li class="menu-item menu-item-parent" aria-haspopup="true">
                            <span class="menu-link">
                                <span class="menu-text"><?php echo e(translate('Missions')); ?></span>
                            </span>
                        </li>



                        <?php $__currentLoopData = \App\Mission::status_info(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php if(in_array($user_type, $item['user_role']) || in_array($item['permissions'], json_decode(Auth::user()->staff->role->permissions ?? "[]"))): ?>
                                <li class="menu-item <?php echo e(areActiveRoutes([$item['route_name']])); ?>" aria-haspopup="true">
                                    <a href="<?php echo e(route($item['route_name'],['status'=>$item['status']])); ?>" class="menu-link">
                                        <i class="menu-bullet menu-bullet-dot">
                                            <span></span>
                                        </i>
                                        <span class="menu-text"><?php echo e($item['text']); ?></span>

                                    </a>
                                </li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
                </div>
            </li>
        <?php endif; ?>

        <?php if(in_array($user_type, ['admin','captain','branch']) || in_array('1008', json_decode(Auth::user()->staff->role->permissions ?? "[]"))): ?>
            <li class="menu-item <?php echo e(areActiveRoutes(['admin.missions.manifests','admin.missions.get.manifest'])); ?>" aria-haspopup="true">
                <a href="<?php echo e(route('admin.missions.manifests')); ?>" class="menu-link">
                    <i class="menu-icon fas fa-people-carry"></i>
                    <span class="menu-text"><?php echo e(translate('Manifest')); ?></span>
                </a>
            </li>
        <?php endif; ?>
    <?php endif; ?>
<?php endif; ?>
<?php if( in_array($user_type,['captain']) || in_array('1109', json_decode(Auth::user()->staff->role->permissions ?? "[]"))): ?>
    <li class="menu-item <?php echo e(areActiveRoutes(['admin.shipments.barcode.scanner'])); ?>" aria-haspopup="true">
        <a href="<?php echo e(route('admin.shipments.barcode.scanner')); ?>" class="menu-link">
            <i class="menu-icon fas fa-barcode"></i>
            <span class="menu-text"><?php echo e(translate('Barcode Scanner')); ?></span>
        </a>
    </li>
<?php endif; ?>
<!-- Clients-->
<?php
$addon = \App\Addon::where('unique_identifier', 'spot-cargo-shipment-addon')->first();
?>
<?php if($addon != null): ?>
    <?php if($addon->activated): ?>

        <!--Users-->
        <?php if(in_array($user_type, ['admin','branch']) || in_array('1005', json_decode(Auth::user()->staff->role->permissions ?? "[]")) || in_array('1006', json_decode(Auth::user()->staff->role->permissions ?? "[]")) || in_array('1007', json_decode(Auth::user()->staff->role->permissions ?? "[]"))): ?>
            <li class="menu-item menu-item-submenu  <?php echo e(areActiveRoutes(['admin.clients.index','admin.clients.update','admin.clients.create','admin.clients.show'])); ?>" aria-haspopup="true" data-menu-toggle="hover">
                <a href="javascript:;" class="menu-link menu-toggle">
                    <i class="menu-icon flaticon-users"></i>
                    <span class="menu-text"><?php echo e(translate('Users')); ?></span>
                    <i class="menu-arrow"></i>
                </a>
                <div class="menu-submenu">
                    <i class="menu-arrow"></i>
                    <ul class="menu-subnav">
                        <li class="menu-item menu-item-parent" aria-haspopup="true">
                            <span class="menu-link">
                                <span class="menu-text"><?php echo e(translate('Users')); ?></span>
                            </span>
                        </li>

                        <!--Customers-->
                        <?php if(in_array($user_type, ['admin','branch']) || in_array('1005', json_decode(Auth::user()->staff->role->permissions ?? "[]"))): ?>
                            <li class="menu-item menu-item-submenu  <?php echo e(areActiveRoutes(['admin.clients.index','admin.clients.update','admin.clients.create','admin.clients.show'])); ?>" aria-haspopup="true" data-menu-toggle="hover">
                                <a href="javascript:;" class="menu-link menu-toggle">
                                    <i class="menu-icon fas fa-users"></i>
                                    <span class="menu-text"><?php echo e(translate('Customers')); ?></span>
                                    <i class="menu-arrow"></i>
                                </a>
                                <div class="menu-submenu">
                                    <i class="menu-arrow"></i>
                                    <ul class="menu-subnav">
                                        <li class="menu-item menu-item-parent" aria-haspopup="true">
                                            <span class="menu-link">
                                                <span class="menu-text"><?php echo e(translate('Customers')); ?></span>
                                            </span>
                                        </li>

                                        <?php if(in_array($user_type, ['admin','branch']) || in_array('1005', json_decode(Auth::user()->staff->role->permissions ?? "[]"))): ?>
                                            <li class="menu-item <?php echo e(areActiveRoutes(['admin.clients.index','admin.clients.update','admin.clients.show'])); ?>" aria-haspopup="true">
                                                <a href="<?php echo e(route('admin.clients.index')); ?>" class="menu-link">
                                                    <i class="menu-bullet menu-bullet-dot">
                                                        <span></span>
                                                    </i>
                                                    <span class="menu-text"><?php echo e(translate('All Customers')); ?></span>

                                                </a>
                                            </li>
                                            <li class="menu-item <?php echo e(areActiveRoutes(['admin.clients.create'])); ?>" aria-haspopup="true">
                                                <a href="<?php echo e(route('admin.clients.create')); ?>" class="menu-link">
                                                    <i class="menu-bullet menu-bullet-dot">
                                                        <span></span>
                                                    </i>
                                                    <span class="menu-text"><?php echo e(translate('Add Customer')); ?></span>

                                                </a>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </li>
                        <?php endif; ?>

                        <!--Branches-->
                        <?php if(Auth::user()->user_type == 'admin' || in_array('1006', json_decode(Auth::user()->staff->role->permissions ?? "[]"))): ?>
                            <li class="menu-item menu-item-submenu  <?php echo e(areActiveRoutes(['admin.branchs.index','admin.branchs.update','admin.branchs.create','admin.branchs.show'])); ?>" aria-haspopup="true" data-menu-toggle="hover">
                                <a href="javascript:;" class="menu-link menu-toggle">
                                    <i class="menu-icon fas fa-map-marked-alt"></i>
                                    <span class="menu-text"><?php echo e(translate('Branches')); ?></span>
                                    <i class="menu-arrow"></i>
                                </a>
                                <div class="menu-submenu">
                                    <i class="menu-arrow"></i>
                                    <ul class="menu-subnav">
                                        <li class="menu-item menu-item-parent" aria-haspopup="true">
                                            <span class="menu-link">
                                                <span class="menu-text"><?php echo e(translate('Branches')); ?></span>
                                            </span>
                                        </li>

                                        <?php if(Auth::user()->user_type == 'admin' || in_array('1006', json_decode(Auth::user()->staff->role->permissions ?? "[]"))): ?>
                                            <li class="menu-item <?php echo e(areActiveRoutes(['admin.branchs.index','admin.branchs.update','admin.branchs.show'])); ?>" aria-haspopup="true">
                                                <a href="<?php echo e(route('admin.branchs.index')); ?>" class="menu-link">
                                                    <i class="menu-bullet menu-bullet-dot">
                                                        <span></span>
                                                    </i>
                                                    <span class="menu-text"><?php echo e(translate('All Branches')); ?></span>

                                                </a>
                                            </li>
                                            <li class="menu-item <?php echo e(areActiveRoutes(['admin.branchs.create'])); ?>" aria-haspopup="true">
                                                <a href="<?php echo e(route('admin.branchs.create')); ?>" class="menu-link">
                                                    <i class="menu-bullet menu-bullet-dot">
                                                        <span></span>
                                                    </i>
                                                    <span class="menu-text"><?php echo e(translate('Add Branch')); ?></span>

                                                </a>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </li>
                        <?php endif; ?>

                        <!--Drivers-->
                        <?php if(in_array($user_type,['admin','branch']) || in_array('1007', json_decode(Auth::user()->staff->role->permissions ?? "[]"))): ?>
                            <li class="menu-item menu-item-submenu  <?php echo e(areActiveRoutes(['admin.captains.index','admin.captains.update','admin.captains.create'])); ?>" aria-haspopup="true" data-menu-toggle="hover">
                                <a href="javascript:;" class="menu-link menu-toggle">
                                    <i class="menu-icon fas fa-people-carry"></i>
                                    <span class="menu-text"><?php echo e(translate('Drivers')); ?></span>
                                    <i class="menu-arrow"></i>
                                </a>
                                <div class="menu-submenu">
                                    <i class="menu-arrow"></i>
                                    <ul class="menu-subnav">
                                        <li class="menu-item menu-item-parent" aria-haspopup="true">
                                            <span class="menu-link">
                                                <span class="menu-text"><?php echo e(translate('Drivers')); ?></span>
                                            </span>
                                        </li>

                                        <?php if(in_array($user_type,['admin','branch']) || in_array('1007', json_decode(Auth::user()->staff->role->permissions ?? "[]"))): ?>
                                            <li class="menu-item <?php echo e(areActiveRoutes(['admin.captains.index','admin.captains.update','admin.captains.create'])); ?>" aria-haspopup="true">
                                                <a href="<?php echo e(route('admin.captains.index')); ?>" class="menu-link">
                                                    <i class="menu-bullet menu-bullet-dot">
                                                        <span></span>
                                                    </i>
                                                    <span class="menu-text"><?php echo e(translate('All Drivers')); ?></span>

                                                </a>
                                            </li>
                                            <li class="menu-item <?php echo e(areActiveRoutes(['admin.captains.create'])); ?>" aria-haspopup="true">
                                                <a href="<?php echo e(route('admin.captains.create')); ?>" class="menu-link">
                                                    <i class="menu-bullet menu-bullet-dot">
                                                        <span></span>
                                                    </i>
                                                    <span class="menu-text"><?php echo e(translate('Add Driver')); ?></span>

                                                </a>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </li>
        <?php endif; ?>

        <!--Reports-->
        <?php if( in_array($user_type,['admin','customer','branch']) || in_array('10', json_decode(Auth::user()->staff->role->permissions ?? "[]"))): ?>
            <li class="menu-item menu-item-submenu  <?php echo e(areActiveRoutes(['admin.shipments.report'])); ?>" aria-haspopup="true" data-menu-toggle="hover">
                <a href="javascript:;" class="menu-link menu-toggle">
                    <i class="menu-icon flaticon2-document"></i>
                    <span class="menu-text"><?php echo e(translate('Reports')); ?></span>
                    <i class="menu-arrow"></i>
                </a>
                <div class="menu-submenu">
                    <i class="menu-arrow"></i>
                    <ul class="menu-subnav">
                        <li class="menu-item menu-item-parent" aria-haspopup="true">
                            <span class="menu-link">
                                <span class="menu-text"><?php echo e(translate('Reports')); ?></span>
                            </span>
                        </li>
                        <li class="menu-item <?php echo e(areActiveRoutes(['admin.shipments.report'])); ?>" aria-haspopup="true">
                            <a href="<?php echo e(route('admin.shipments.report')); ?>" class="menu-link">
                                    <i class="menu-bullet menu-bullet-dot" style="font-size: 10px;"></i>
                                <span class="menu-text"><?php echo e(translate('Shipments Report')); ?></span>
                            </a>
                        </li>


                    </ul>
                </div>
            </li>
        <?php endif; ?>

        <!--Transactions-->
        <?php if( in_array($user_type,['admin']) || in_array('1106', json_decode(Auth::user()->staff->role->permissions ?? "[]"))): ?>
            <li class="menu-item menu-item-submenu  <?php echo e(areActiveRoutes(['admin.transactions.index','admin.transactions.create'])); ?>" aria-haspopup="true" data-menu-toggle="hover">
                <a href="javascript:;" class="menu-link menu-toggle">
                    <i class="menu-icon fas fa-coins"></i>
                    <span class="menu-text"><?php echo e(translate('Transactions')); ?></span>
                    <i class="menu-arrow"></i>
                </a>
                <div class="menu-submenu">
                    <i class="menu-arrow"></i>
                    <ul class="menu-subnav">
                        <li class="menu-item menu-item-parent" aria-haspopup="true">
                            <span class="menu-link">
                                <span class="menu-text"><?php echo e(translate('Transactions')); ?></span>
                            </span>
                        </li>
                        <li class="menu-item <?php echo e(areActiveRoutes(['admin.transactions.index'])); ?>" aria-haspopup="true">
                            <a href="<?php echo e(route('admin.transactions.index')); ?>" class="menu-link">
                                    <i class="menu-bullet menu-bullet-dot" style="font-size: 10px;"></i>
                                <span class="menu-text"><?php echo e(translate('All Transactions')); ?></span>
                            </a>
                        </li>
                        <li class="menu-item <?php echo e(areActiveRoutes(['admin.transactions.create'])); ?>" aria-haspopup="true">
                            <a href="<?php echo e(route('admin.transactions.create')); ?>" class="menu-link">
                                    <i class="menu-bullet menu-bullet-dot" style="font-size: 10px;"></i>
                                <span class="menu-text"><?php echo e(translate('Add New Transaction')); ?></span>
                            </a>
                        </li>


                    </ul>
                </div>
            </li>
        <?php endif; ?>
    <?php endif; ?>
<?php endif; ?>

<!--Settings-->
<?php if($addon != null): ?>
    <?php if($addon->activated): ?>
        <?php if($user_type == 'admin' || in_array('1105', json_decode(Auth::user()->staff->role->permissions ?? "[]"))): ?>
            <li class="menu-item menu-item-submenu  <?php echo e(areActiveRoutes(['admin.shipments.barcode.scanner','admin.deliveryTime.index','admin.packages.index','admin.shipments.settings','admin.shipments.covered_countries','admin.areas.index','admin.areas.create','admin.shipments.settings.fees'])); ?>" aria-haspopup="true" data-menu-toggle="hover">
                <a href="javascript:;" class="menu-link menu-toggle">
                    <i class="menu-icon fas fa-cogs"></i>
                    <span class="menu-text"><?php echo e(translate('Shipment Settings')); ?></span>
                    <i class="menu-arrow"></i>
                </a>
                <div class="menu-submenu">
                    <i class="menu-arrow"></i>
                    <ul class="menu-subnav">
                        <li class="menu-item menu-item-parent" aria-haspopup="true">
                            <span class="menu-link">
                                <span class="menu-text"><?php echo e(translate('Shipment Settings')); ?></span>
                            </span>
                        </li>
                        <li class="menu-item <?php echo e(areActiveRoutes(['admin.deliveryTime.index'])); ?>" aria-haspopup="true">
                            <a href="<?php echo e(route('admin.deliveryTime.index')); ?>" class="menu-link">
                                <i class="menu-bullet menu-bullet-dot">
                                    <span></span>
                                </i>
                                <span class="menu-text"><?php echo e(translate('Delivery Times')); ?></span>
                            </a>
                        </li>
                        <li class="menu-item <?php echo e(areActiveRoutes(['admin.packages.index'])); ?>" aria-haspopup="true">
                            <a href="<?php echo e(route('admin.packages.index')); ?>" class="menu-link">
                                <i class="menu-bullet menu-bullet-dot">
                                    <span></span>
                                </i>
                                <span class="menu-text"><?php echo e(translate('Package Types')); ?></span>
                            </a>
                        </li>
                        <li class="menu-item <?php echo e(areActiveRoutes(['admin.shipments.covered_countries'])); ?>" aria-haspopup="true">
                            <a href="<?php echo e(route('admin.shipments.covered_countries')); ?>" class="menu-link">
                                <i class="menu-bullet menu-bullet-dot">
                                    <span></span>
                                </i>
                                <span class="menu-text"><?php echo e(translate('Covered Places')); ?></span>
                            </a>
                        </li>
                        <li class="menu-item <?php echo e(areActiveRoutes(['admin.areas.index','admin.areas.create'])); ?>" aria-haspopup="true">
                            <a href="<?php echo e(route('admin.areas.index')); ?>" class="menu-link">
                                <i class="menu-bullet menu-bullet-dot">
                                    <span></span>
                                </i>
                                <span class="menu-text"><?php echo e(translate('Areas Management')); ?></span>
                            </a>
                        </li>
                        <li class="menu-item <?php echo e(areActiveRoutes(['admin.shipments.settings.fees'])); ?>" aria-haspopup="true">
                            <a href="<?php echo e(route('admin.shipments.settings.fees')); ?>" class="menu-link">
                                <i class="menu-bullet menu-bullet-dot">
                                    <span></span>
                                </i>
                                <span class="menu-text"><?php echo e(translate('Shipping rates')); ?></span>
                            </a>
                        </li>
                        <li class="menu-item <?php echo e(areActiveRoutes(['admin.shipments.settings'])); ?>" aria-haspopup="true">
                            <a href="<?php echo e(route('admin.shipments.settings')); ?>" class="menu-link">
                                <i class="menu-bullet menu-bullet-dot">
                                    <span></span>
                                </i>
                                <span class="menu-text"><?php echo e(translate('General Settings')); ?></span>
                            </a>
                        </li>

                    </ul>
                </div>
            </li>
        <?php endif; ?>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH /Volumes/Collection/Algoriza/Bdaia/Codecanyon/framework/resources/views/backend/inc/addons/shipment_sidenav.blade.php ENDPATH**/ ?>