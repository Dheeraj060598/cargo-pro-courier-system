<?php $__env->startSection('content'); ?>

		<!--begin::Main-->
		<div class="d-flex flex-column flex-root">
			<!--begin::Login-->
			<div class="login login-4 login-signin-on d-flex flex-row-fluid" id="kt_login">
				<div class="d-flex flex-center flex-row-fluid bgi-size-cover bgi-position-top bgi-no-repeat" style="background-image: url('<?php echo e(static_asset('assets/dashboard/media/bg/bg-3.jpg')); ?>');">
					<div class="overflow-hidden text-center login-form p-7 position-relative">
						<!--begin::Login Header-->
						<div class="mb-5 d-flex flex-center">
							<a href="#">
                                <?php if(get_setting('system_logo_black') != null): ?>
                                    <img src="<?php echo e(uploaded_asset(get_setting('system_logo_black'))); ?>" alt="<?php echo e(get_setting('site_name')); ?>" class="max-h-75px" style="width:100%">
                                <?php else: ?>
                                    <img src="<?php echo e(static_asset('assets/img/logo.svg')); ?>" alt="<?php echo e(get_setting('site_name')); ?>" class="max-h-75px">
                                <?php endif; ?>
							</a>
						</div>
						<!--end::Login Header-->
						<!--begin::Login Sign in form-->
						<div class="login-signin">
							<div class="mb-20">
								<h3><?php echo e(translate('Welcome to')); ?> <?php if(get_setting('site_name')): ?> <?php echo e(get_setting('site_name')); ?> <?php else: ?> <?php echo e(translate('Spotlayer Framework')); ?>  <?php endif; ?></h3>
								<div class="text-muted font-weight-bold"><?php echo e(translate('Login to your account.')); ?></div>
							</div>
							<?php if(env('DEMO_MODE') == 'On'): ?>
								<div class="mb-10">
									<table class="kt-form" style="padding: 10px !important;margin: 0;width: 100%;border: 1px solid #eee;">
										<tbody>
											<tr>
												<td colspan="3" style="text-align: center;background: #eee;color: #000;font-size: 24px;font-weight: bold;text-transform: uppercase;padding: 10px;">
													<?php echo e(translate('Demo Login Details')); ?>

												</td>
											</tr>
											<tr>
												<td colspan="3" style="text-align: left;background: #fff000;padding: 10px;color: #000;border: 1px solid #ccc;">
													<?php echo e(translate("If any user from below didn't work for any reason, it may be a visitor has changed it's data, the data will be reset again every 12 hours")); ?>.
												</td>
											</tr>
											<tr>
												<td style="text-align: left;border-bottom: 1px solid #eee;font-weight:bold;padding: 0 10px;">
													<?php echo e(translate('ADMIN')); ?>

													<br />
													<span id="login_admin" class="text-muted font-size-xs font-weight-normal"><?php echo e(translate('Click to Copy')); ?></span>
												</td>
												<td style="text-align: left;border-bottom: 1px solid #eee;padding: 0 10px">admin@cargo.com</td>
												<td style="text-align: right;border-bottom: 1px solid #eee;">123456</td>
											</tr>
											<tr>
												<td style="border-bottom: 1px solid #eee;text-align: left;font-weight:bold;padding: 0 10px;">
													<?php echo e(translate('EMPLOYEE')); ?>

													<br />
													<span id="login_employee" class="text-muted font-size-xs font-weight-normal"><?php echo e(translate('Click to Copy')); ?></span>
												</td>
												<td style="border-bottom: 1px solid #eee;text-align: left;padding: 0 10px">employee@cargo.com</td>
												<td style="border-bottom: 1px solid #eee;text-align: right;">123456</td>
											</tr>
											<tr>
												<td style="border-bottom: 1px solid #eee;text-align: left;font-weight:bold;padding: 0 10px;">
													<?php echo e(translate('BRANCH MANAGER')); ?>

													<br />
													<span id="login_branch" class="text-muted font-size-xs font-weight-normal"><?php echo e(translate('Click to Copy')); ?></span>
												</td>
												<td style="border-bottom: 1px solid #eee;text-align: left;padding: 0 10px">branch@cargo.com</td>
												<td style="border-bottom: 1px solid #eee;text-align: right;">123456</td>
											</tr>
											<tr>
												<td style="border-bottom: 1px solid #eee;text-align: left;font-weight:bold;padding: 0 10px;">
													<?php echo e(translate('DRIVER/CAPTAIN')); ?>

													<br />
													<span id="login_driver" class="text-muted font-size-xs font-weight-normal"><?php echo e(translate('Click to Copy')); ?></span>
												</td>
												<td style="border-bottom: 1px solid #eee;text-align: left;padding: 0 10px">driver@cargo.com</td>
												<td style="border-bottom: 1px solid #eee;text-align: right;">123456</td>
											</tr>
											<tr>
												<td style="border-bottom: 1px solid #eee;text-align: left;font-weight:bold;padding: 0 10px;">
													<?php echo e(translate('CLIENT')); ?>

													<br />
													<span id="login_client" class="text-muted font-size-xs font-weight-normal"><?php echo e(translate('Click to Copy')); ?></span>
												</td>
												<td style="text-align: left;padding: 0 10px">client@cargo.com</td>
												<td style="text-align: right;">123456</td>
											</tr>
										</tbody>
									</table>
								</div>
							<?php endif; ?>
                            <form class="form" method="POST" role="form" action="<?php echo e(route('login')); ?>">
                                <?php echo csrf_field(); ?>
								<div class="mb-5 form-group">
                                    <input id="email" type="email" class="form-control h-auto form-control-solid py-4 px-8 <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus placeholder="<?php echo e(translate('Email')); ?>">
                                    <?php if($errors->has('email')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
								</div>
								<div class="mb-5 form-group">
                                    <input id="password" type="password" class="form-control h-auto form-control-solid py-4 px-8 <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required placeholder="<?php echo e(translate('Password')); ?>">
                                    <?php if($errors->has('password')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
								</div>
								<div class="flex-wrap form-group d-flex justify-content-between align-items-center">
									<div class="checkbox-inline">
										<label class="m-0 checkbox text-muted">
                                            <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
										<span></span><?php echo e(translate('Remember me')); ?></label>
									</div>
                                    <?php if(env('MAIL_USERNAME') != null && env('MAIL_PASSWORD') != null): ?>
                                        <a href="<?php echo e(route('password.request')); ?>" class="text-muted text-hover-primary"><?php echo e(translate('Forgot password ?')); ?></a>
                                    <?php endif; ?>
								</div>
								<button type="submit" class="py-4 mx-4 my-3 btn btn-primary font-weight-bold px-9"><?php echo e(translate('Login')); ?></button>
							</form>
							<?php if(\App\Addon::where('activated', 1)->count() > 0): ?>
								<?php $__currentLoopData = \File::files(base_path('resources/views/backend/inc/addons/login')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $path): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php echo $__env->make('backend.inc.addons.login.'.str_replace('.blade','',pathinfo($path)['filename']), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
						</div>
						<!--end::Login Sign in form-->

					</div>
				</div>
			</div>
			<!--end::Login-->
		</div>
		<!--end::Main-->



<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        function autoFill(){
            $('#email').val('admin@cargo.com');
            $('#password').val('123456');
        }


		// Class Initialization
		$(document).ready(function() {
			autoFill();

			$('body').on('click','#login_admin', function(e){
				$('#email').val('admin@cargo.com');
				$('#password').val('123456');
				$('#signin_submit').trigger('click');
			});
			$('body').on('click','#login_employee', function(e){
				$('#email').val('employee@cargo.com');
				$('#password').val('123456');
				$('#signin_submit').trigger('click');
			});
			$('body').on('click','#login_driver', function(e){
				$('#email').val('driver@cargo.com');
				$('#password').val('123456');
				$('#signin_submit').trigger('click');
			});
			$('body').on('click','#login_branch', function(e){
				$('#email').val('branch@cargo.com');
				$('#password').val('123456');
				$('#signin_submit').trigger('click');
			});
			$('body').on('click','#login_client', function(e){
				$('#email').val('client@cargo.com');
				$('#password').val('123456');
				$('#signin_submit').trigger('click');
			});

		});
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.blank', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Collection/Algoriza/Bdaia/Codecanyon/framework/resources/views/auth/login.blade.php ENDPATH**/ ?>