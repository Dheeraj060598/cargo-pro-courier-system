<?php $__env->startSection('sub_title'); ?><?php echo e(translate('Dashboard')); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(env('MAIL_USERNAME') == null && env('MAIL_PASSWORD') == null): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(translate('Please Configure Email Setting to work all email sending funtionality')); ?>,
            <a class="alert-link" href="<?php echo e(route('email_settings.index')); ?>"><?php echo e(translate('Configure Now')); ?></a>
        </div>
    <?php endif; ?>

    <?php if(\App\Addon::where('activated', 1)->count() > 0): ?>
        <?php $__currentLoopData = \File::files(base_path('resources/views/backend/inc/addons/dashboard')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $path): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('backend.inc.addons.dashboard.'.str_replace('.blade','',pathinfo($path)['filename']), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Collection/Algoriza/Bdaia/Codecanyon/framework/resources/views/backend/dashboard.blade.php ENDPATH**/ ?>