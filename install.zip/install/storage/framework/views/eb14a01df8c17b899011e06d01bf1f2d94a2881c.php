<?php $__env->startSection('content'); ?>
    <div id="wizard">
        <h4>Checking file permissions</h4>
        <a class="steps"><span class="current-info audible"></span><span class="number">1.</span> </a>
        <a class="steps current"><span class="current-info audible">current step: </span><span class="number">2.</span> </a>
        <a class="steps"><span class="current-info audible"></span><span class="number">3.</span> </a>
        <a class="steps"><span class="current-info audible"></span><span class="number">4.</span> </a>
        <a class="steps"><span class="current-info audible"></span><span class="number">5.</span> </a>
        <a class="steps"><span class="current-info audible"></span><span class="number">6.</span> </a>
        <a class="steps last"><span class="current-info audible"></span><span class="number">7.</span> </a>
        <section>
            <div class="form-row">
                <div class="tooltip"> We ran diagnosis on your server. Review the items that have a red mark on it. <br> If everything is green, you are good to go to the next step. </div>

                <ul class="list-group">
                    <?php
                        $phpVersion = number_format((float)phpversion(), 2, '.', '');
                    ?>
                    <li class="list-group-item text-semibold check <?php if($phpVersion >= 7.20): ?> check success <?php else: ?> close faild <?php endif; ?>">
                        Php version 7.2 +
                    </li>
                    <li class="list-group-item text-semibold <?php if($permission['curl_enabled']): ?> check success <?php else: ?> close faild <?php endif; ?>">
                        Curl Enabled
                    </li>
                    <li class="list-group-item text-semibold check <?php if($permission['db_file_write_perm']): ?> check success <?php else: ?> close faild <?php endif; ?>">
                        <b>.env</b> File Permission
                    </li>
                    <li class="list-group-item text-semibold check <?php if($permission['routes_file_write_perm']): ?> check success <?php else: ?> close faild <?php endif; ?>">
                        <b>RouteServiceProvider.php</b> File Permission
                    </li>
                </ul>
            </div>
            
            <div class="actions">
                <ul>
                    <li><a href="<?php echo e(url('/')); ?>">Previous</a></li>

                    <?php if($permission['curl_enabled'] == 1 && $permission['db_file_write_perm'] == 1 && $permission['routes_file_write_perm'] == 1 && $phpVersion >= 7.20): ?>
                        <?php if($_SERVER['SERVER_NAME'] == 'localhost' || $_SERVER['SERVER_NAME'] == '127.0.0.1'): ?>
                            <li><a href="<?php echo e(route('step3')); ?>" class="next">Next</a></li>
                        <?php else: ?>
                            <li><a href="<?php echo e(route('step2')); ?>" class="next">Next</a></li>
                        <?php endif; ?>
                    <?php endif; ?>
                </ul>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('installation.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Collection/Algoriza/Bdaia/Codecanyon/framework/resources/views/installation/step1.blade.php ENDPATH**/ ?>